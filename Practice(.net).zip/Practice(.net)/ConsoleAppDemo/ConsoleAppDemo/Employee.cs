﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleAppDemo
{
    class Emp
    {
        private int eid;
        private string ename;
        private int salary;
        private string department;

        public int Eid { get => eid; set => eid = value; }
        public string Ename { get => ename; set => ename = value; }
        public int Salary { get => salary; set => salary = value; }
        public string Department { get => department; set => department = value; }
    }
    class Dept
    {
        private int did;
        private string department;

        public int Did { get => did; set => did = value; }
        public string Department { get => department; set => department = value; }
    }
    class EmpData
    {
        //Step 1 Source code creation
        public void AddData()
        {
            List<Emp> list = new List<Emp>();

            list.Add(new Emp() { Eid = 101, Ename = "Archana", Salary = 25000, Department = "Developer" });
            list.Add(new Emp() { Eid = 102, Ename = "Tejal", Salary = 30000, Department = "Tester" });
            list.Add(new Emp() { Eid = 103, Ename = "Kajal", Salary = 40000, Department = "HR" });
            list.Add(new Emp() { Eid = 104, Ename = "Mahesh", Salary = 44000, Department = "Manager" });
            list.Add(new Emp() { Eid = 105, Ename = "Akul", Salary = 23000, Department = "Developer" });


            List<Dept> list1 = new List<Dept>();
            list1.Add(new Dept() { Did = 10, Department = "Developer" });
            list1.Add(new Dept() { Did = 11, Department = "Tester" });
            list1.Add(new Dept() { Did = 12, Department = "Manager" });
           // list1.Add(new Dept() { Did = 13, Department = "HR" });


            foreach (Emp e in list)
            {
                Console.WriteLine(e.Eid+" "+e.Ename+" "+e.Salary+" "+e.Department);
            }
            //Step 2 Query creation

            //var query = from lst in list where lst.Ename == "Archana" && lst.Department == "Developer" select lst.Ename;
            var query = from lst in list where lst.Eid == 101 && lst.Department == "Developer" select lst.Ename;

            //step 3 query Excecution
            foreach (string ename in query)
            {
                Console.WriteLine(ename);
            }
            //using group by
            var query1 = from lst1 in list group lst1 by lst1.Department;

            foreach(var val in query1)
            {
                foreach(Emp e in val)
                {
                    Console.WriteLine(e.Ename);
                }
            }
            //select all
            var query2 = from lst2 in list select lst2;
            
            foreach(var e1 in query2)
            {
                Console.WriteLine(e1.Eid + " " + e1.Ename + " " + e1.Salary + " " + e1.Department);
            }
            Console.WriteLine("Order by salary ");
            //order by
            var query3 = from lst3 in list orderby lst3.Salary descending select lst3;

            foreach (var e2 in query3)
            {
                Console.WriteLine(e2.Eid + " " + e2.Ename + " " + e2.Salary + " " + e2.Department);

            }
            Console.WriteLine("Inner Join");
            var innerJoin = from s in list join st in list1 on s.Department equals st.Department select s.Ename;

            foreach(string e3 in innerJoin)
            {
                Console.WriteLine(e3);
            }
            //var innerJoin = from s in studentList // outer sequence
            //                join st in standardList //inner sequence 
            //                on s.StandardID equals st.StandardID // key selector 
            //                select new
            //                { // result selector 
            //                    StudentName = s.StudentName,
            //                    StandardName = st.StandardName
            //                };


        }
    }

    class Employee
    {
        static void Main(string[] args)
        {
            EmpData obj = new EmpData();
            obj.AddData();
            Console.ReadKey();
        }
    }
}
