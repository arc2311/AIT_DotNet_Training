﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppDemo
{
    
        public class Employee1
        {
            private int eId;
            private string name;
            private int salary;
            private int dep;


            public int EId { get => eId; set => eId = value; }
            public string Name { get => name; set => name = value; }
            public int Salary { get => salary; set => salary = value; }
            public int Dep { get => dep; set => dep = value; }

            // public int eId { get;  set; }
            //public string name { get; set; }

            // public int salary { get; set; }
        }

    class GetSetDemo
    {

        public void getData()
            {
                //Employee1 e1 = new Employee1();


                var e = new Employee1();
                Console.WriteLine("Enter RollNo");
                e.EId = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Name");
                e.Name = Console.ReadLine();

                Console.WriteLine("Enter Salary");
                e.Salary = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Depatment Id");
                e.Dep = Convert.ToInt32(Console.ReadLine());



                Console.WriteLine("Employee ID: " + e.EId);
                Console.WriteLine("Employee Name: " + e.Name);
                Console.WriteLine("Employee Salary: " + e.Salary);

            }
        }
}
