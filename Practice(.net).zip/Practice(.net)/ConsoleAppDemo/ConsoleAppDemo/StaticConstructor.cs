﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleAppDemo
{
    class Demo
    {
       public  static int a = 10;

        static Demo()
        {
            a++;
        }
        public Demo(string name)
        {
            Console.WriteLine(name);
        }
    }
    class StaticConstructor
    {
        static void Main(string[] args)
        {
            Demo o = new Demo("Archana");
            Console.WriteLine(Demo.a);
            Console.ReadKey();
        }
    }
}
