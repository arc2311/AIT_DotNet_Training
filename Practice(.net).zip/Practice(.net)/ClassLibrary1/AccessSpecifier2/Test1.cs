﻿using System;

namespace AccessSpecifier2
{
    public class Test1
    {
        protected char ch = 'A';

        protected void Charshow()
        {
            Console.WriteLine('B');
        }
    }
}
