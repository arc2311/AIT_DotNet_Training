﻿using System;

namespace AccessSpecifier
{
    public class Class1
    {
        public int a = 20;
        public void Show()
        {
            Console.WriteLine("Hello");
        }
    }
}
