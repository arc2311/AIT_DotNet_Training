﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccessSpecifier
{
    class Class2
    {
        protected string s = "Hello";
        //private float b=20f;
           
        //    private float Display()
        //    {
        //    return b;
        // }
    }
}
