﻿using System;

namespace AccessSpecifier1
{
    public  class Test
    {
        private int b = 10;
        private void Display()
        {
            Console.WriteLine(b);
        }
    }
}
