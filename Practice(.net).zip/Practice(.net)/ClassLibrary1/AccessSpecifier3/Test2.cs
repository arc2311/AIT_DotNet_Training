﻿using System;

namespace AccessSpecifier3
{
    public class Test2
    {
        internal string s = "Hello";

        //internal string Print()
        //{
        //    return "World";
        //}
    }
}
