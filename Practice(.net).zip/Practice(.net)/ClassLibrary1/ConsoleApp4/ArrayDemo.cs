﻿using System;
using System.Text;

namespace ConsoleApp4
{
    class ArrayDemo
    {
        //static void Main(string[] args)
        //{
        //    int[] arr;
        //    arr = new int[5];

        //    Console.WriteLine("Enter Numbers:");
        //    for(int i=0;i<arr.Length;i++)
        //    {
        //        arr[i] = Convert.ToInt32(Console.ReadLine());
                    
        //    }

        //    foreach(int a in arr)
        //    {
        //        Console.WriteLine(a);
        //    }

        //    string s = "hi";//data type
        //    String str = "Hello";//class
        //    String str1 = new String("Good");
        //    Console.WriteLine(s);
        //    Console.WriteLine(str);
        //    Console.WriteLine(str1);

        //    StringBuilder b = new StringBuilder("Hello");
        //    b.Append("World");
        //    Console.WriteLine(b);
        //    StringBuilder b1 = new StringBuilder();
        //    b = b.Append("World");
        //    Console.WriteLine(b1);

        //}
    }
}
