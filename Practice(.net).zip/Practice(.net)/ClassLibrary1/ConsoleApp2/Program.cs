﻿using System;
using AccessSpecifier;
namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {

            Class1 o = new Class1();
            int a = o.Show();
            Console.WriteLine(a);
            //int a = 20;
            //int b = 30;

            //Console.WriteLine("Addition"+(a + b));
            //Console.WriteLine("Subtraction" + (a - b));
            //Console.WriteLine("Multiplication" + (a * b));
            //Console.WriteLine("Division" + (b / a));
            //Console.WriteLine(a % b);
            //Console.WriteLine("Increment"+a++);
            //Console.WriteLine("Decrement"+b--);
            //Console.WriteLine("Increment" + ++a);
            //Console.WriteLine("Decrement" + --b);
            //Console.WriteLine(a << b);
            //Console.WriteLine(a >> b);
            //Console.WriteLine(a ^ b);


            //if(a>10 && a<30)
            //{
            //    Console.WriteLine("a is between 10 to 30");
            //}

            //int num = 1;
            //while(num<=10)
            //{
            //    Console.WriteLine(2 * num);
            //    num++;
            //}

            //int n = 1;
            //do
            //{

            //    Console.WriteLine(5);
            //    n++;
            //} while (n < 5);


            //for(int i=1;i<6;i++)
            //{
            //    Console.WriteLine(i);

            //}

            //int x = 2;

            //switch(x)
            //{
            //    case 1:
            //        Console.WriteLine("Monday");
            //        break;
            //    case 2:
            //        Console.WriteLine("Tuesday");
            //        break;
            //    case 3:
            //        Console.WriteLine("Wendesday");
            //        break;
            //    case 4:
            //        Console.WriteLine("Thursday");
            //        break;
            //    case 5:
            //        Console.WriteLine("Friday");
            //        break;
            //    case 6:
            //        Console.WriteLine("Saturday");
            //        break;
            //    case 7:
            //        Console.WriteLine("Sunday");
            //        break;
            //}
        }
    }
}
