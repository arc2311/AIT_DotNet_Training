﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVCPractice.Models;

namespace MVCPractice.Controllers
{
    public class TagHelperExController : Controller
    {
        [HttpGet]
        public IActionResult GetTagHelperValue()
        {
            Student stud = new Student();
            return View(stud);
        }
        [HttpPost]
        public IActionResult GetTagHelperValue(Student stud)
        {
            
            ViewBag.StudObj = stud;
            return View("Show");
         

        }
    }
}