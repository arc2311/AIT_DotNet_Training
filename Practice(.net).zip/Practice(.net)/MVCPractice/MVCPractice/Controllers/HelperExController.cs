﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace MVCPractice.Controllers
{
    public class HelperExController : Controller
    {
        [HttpGet]
        public IActionResult GetHelperTextBoxValue()
        {
            return View();
        }
        [HttpPost]
        public IActionResult GetHelperTextBoxValue(string name)
        {
            return View("Display",(object)name);
        }
    }
}