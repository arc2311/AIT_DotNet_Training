﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVCPractice.Models;

namespace MVCPractice.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult EmployeeInfo()
        {
            List<EmpData> list = new List<EmpData>();

            EmpData e = new EmpData();
            e.Ename = "Archana";
            e.Eid = 10;
            e.Salary = 20000.0f;
            e.Did = 101;
            e.Dname = "Developer";

            EmpData e1 = new EmpData();
            e1.Ename = "Neha";
            e1.Eid = 11;
            e1.Salary = 22000.0f;
            e1.Did = 102;
            e1.Dname = "Manager";

            list.Add(e);
            list.Add(e1);

            //ViewBag.EmployeeObj = list;

            return View(list);
        }

        public IActionResult DAnnota()
        {
            EmpData emp = new EmpData();

            return View(emp);
        }
    }
}