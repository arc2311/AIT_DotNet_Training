﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace MVCPractice.Models
{
    public class EmpData
    {
        private string ename;
        private int eid;
        private float salary;
        private int did;
        private string dname;

        [Required (ErrorMessage ="Please Enter Name")]
        [StringLength(10, ErrorMessage = "Please Do not Enter More than 10 numbers")]

        public string Ename { get => ename; set => ename = value; }

        [StringLength (10,ErrorMessage ="Please Do not Enter More than 10 numbers")]
        public int Eid { get => eid; set => eid = value; }

        [Range(3,5,ErrorMessage ="Salary should be between 3 to 5 digits")]
        public float Salary { get => salary; set => salary = value; }

        [Required (ErrorMessage ="Please Enter Department id")]

        public int Did { get => did; set => did = value; }

        [StringLength(30, ErrorMessage = "Please Do not Enter More than 30 ")]

        public string Dname { get => dname; set => dname = value; }
    }
}
