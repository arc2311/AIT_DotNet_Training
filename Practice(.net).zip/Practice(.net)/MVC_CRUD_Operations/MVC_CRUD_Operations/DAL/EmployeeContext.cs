﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MVC_CRUD_Operations.Models;

namespace MVC_CRUD_Operations.DAL
{
    public class EmployeeContext : DbContext
    {
        public EmployeeContext(DbContextOptions<EmployeeContext> options) :base(options)
        {

        }

        public DbSet<Employee> Employees { get; set; }

        public DbSet<MVC_CRUD_Operations.Models.EmployeeViewModel> EmployeeViewModel { get; set; }
    }
}
