﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Security.Claims;


namespace MVCActionFilterDemo.Controllers
{
    public class AuthorizeActionFilter : IAuthorizationFilter
    {
        private readonly string _permission;

        public AuthorizeActionFilter(string permission)
        {
            _permission = permission;
        }
        public void OnAuthorization(AuthorizationFilterContext context)
        {
            bool isAuthorized = CheckUserPermission(context.HttpContext.User, _permission);

            if(!isAuthorized)
            {
                context.Result = new UnauthorizedResult();
            }
        }
        private bool CheckUserPermission(ClaimsPrincipal user,string permission)
        {
            //get permission details and validate using DB table
            //temp i set permissions as Read only
            return permission == "Read";
        }
    }
    //craete attribute class to validate permission
    public class AuthorizeAttribute : TypeFilterAttribute
    {
        public AuthorizeAttribute(string permission) :base (typeof(AuthorizeActionFilter))
        {
            Arguments = new object[] { permission };
        }
    }
}
