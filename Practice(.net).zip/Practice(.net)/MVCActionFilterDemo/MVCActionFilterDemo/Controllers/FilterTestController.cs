﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace MVCActionFilterDemo.Controllers
{
    public class FilterTestController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [Authorize("Read")]
        public IActionResult Read()
        {
            return View();
        }

        [Authorize("Write")]

        public IActionResult Write()
        {
            return View();
        }
        [CacheResource]
        public IActionResult CacheTest()
        {
            //return Content("This Content Generated at "+DateTime.Now);
            return View();
        }
        [ValidateModel]
        public IActionResult ActionFilterTest(string name)
        {
            return View();
        }
        public IActionResult GenerateError()
        {
            throw new NotImplementedException();
        }
    }
}