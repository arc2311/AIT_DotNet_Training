﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    //sealed class Animal
   sealed class Animal
    {
        public virtual void eat()
        {
            Console.WriteLine("Eating");
        }
    }
    class Dog : Animal
    {
        public override void bark()
        {
            Console.WriteLine("Barking");
        }
    }
    class SealedClassEx
    {
        static void Main(string[] args)
        {
            Dog d = new Dog();
            d.bark();

        }
       
}
}
*/