﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Demo
    {
        public void Round()       
        {
            int a = 10;
            int b = 30;
            int c = a + b;
            Console.WriteLine(c);

        }
    }
}
