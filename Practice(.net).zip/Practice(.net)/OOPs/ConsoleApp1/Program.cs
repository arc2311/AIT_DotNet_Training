﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10, b = 20;
            int c = a + b;
            Console.WriteLine("Hello World!"+c);

            Console.WriteLine("Hello World!");
            Demo d = new Demo();
            d.Round();
        }
    }
}
