﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVCRegistrationForm.Models;

namespace MVCRegistrationForm.Controllers
{
    public class RegistrationFormController : Controller
    {
        [HttpGet]
        public IActionResult GetFormValue()
       
        {
            Student stud = new Student();
            return View(stud);
        }
        [HttpPost]
        public IActionResult GetFormValue(Student stud)

        {
            List<Student> list = new List<Student>();
            list.Add(stud);
            //ViewBag.StudentObj = stud;
            return View("ShowData",list);
        }

    }
}