﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace MVCRegistrationForm.Models
{
    public class Student
    {

        private int studentID;
        private string firstName;
        private string lastName;
        private int marks;
        private string email;
        private string password;
        private string department;
        private int mobile;
        //  [ScaffoldColumn(false)]

        public int StudentID { get; set; }

        [DataType(DataType.Text)]
        [Required(ErrorMessage = "Please enter name")]
        [StringLength(30,ErrorMessage ="Please do not enter more than 30 char")]
        [Display(Name = "Student First Name")]

        public string FirstName { get; set; }

        [DataType(DataType.Text)]
        [Required(ErrorMessage = "Please enter name")]
        [StringLength(30, ErrorMessage = "Please do not enter more than 30 char")]

        [Display(Name = "Student Last Name")]

        public string LastName { get; set; }

        [Range(50,100)]
        [Required(ErrorMessage = "Please enter marks")]
        public int Marks { get; set; }


        [DataType(DataType.EmailAddress)]
        [Required(ErrorMessage = "Please enter Email ID")]
        //[RegularExpression(@"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$", ErrorMessage = "Email is not valid.")]

        public string Email { get; set; }


        [DataType(DataType.Password)]
        
        [Required(ErrorMessage = "Please enter Password")]
       
        public string Password { get; set; }

        [Required(ErrorMessage = "Please enter department")]


        public string Department { get; set; }



        [Required(ErrorMessage = "Please enter Mobile No")]
        [Display(Name = "Contact Number")]
        [DataType(DataType.PhoneNumber)]
        public int Mobile { get; set; }
    }
}
